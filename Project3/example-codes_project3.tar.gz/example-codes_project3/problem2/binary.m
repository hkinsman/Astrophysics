% this is the main code to estimate the binary evolution
% two functions: energy.m and RK4.m are used in this code.
% See section 24, Octave tutorial for Function m-files
% Define mp, ms, x(1)-x(8) and tmax

clear;clf          
h      = 1.d-2;  % time-step size
Ns     = 100  ;  % sampling
%-----------------
mp    =  ??? ;  % primary mass
ms    =  ??? ;  % secondary mass
x(1)  =  ??? ;  % primary x
x(2)  =  ??? ;  % primary y
x(3)  =  ??? ;  % primary vx
x(4)  =  ??? ;  % primary vy
x(5)  =  ??? ;  % secondary x
x(6)  =  ??? ;  % secondary y
x(7)  =  ??? ;  % secondary vx
x(8)  =  ??? ;  % secondary vy
tmax  =  ??? ;  % final time
%-----------------
t      =  0  ;  % initial time
tprint =  t;
dtp    =  (tmax-t)/Ns;
while t < tmax
     if  t >= tprint
         E = energy(x,mp,ms);       % Estimat binary energy
         v = [t x(1) x(2) x(5) x(6) E]; 
         save out v -ascii -append  % save the v vector in the file out           
         tprint =  tprint + dtp;
     end
     x = RK4(h,t,x,mp,ms); % Runge-Kutta method 
     t = t+h;
end
