function [t, x] =  initialc(D,mb,mp,ms)
% input valiables: D,mb,mp,ms. D=Rp/Rtidal is the penetration factor. 
% out variables: t and x. Note that x is a vector. 
% Define the initial values of t and x as functions of the input valiables. 
t    = ??? ; % initial time
x(1) = ??? ; % x : primary star
x(2) = ??? ; % y
x(3) = ??? ; % dx/dt
x(4) = ??? ; % dy/dt
x(5) = ??? ; % x : secondary star
x(6) = ??? ; % y
x(7) = ??? ; % dx/dt
x(8) = ??? ; % dy/dt
