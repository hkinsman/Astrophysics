clear; clf;
out=load('out'); % load the data file out
t =out(:,1); % time 
xp=out(:,2); % the position of the primary star
yp=out(:,3);
xs=out(:,4); % the position of the secondary star
ys=out(:,5); 
Ep=out(:,6); % the energy of the primary star
Es=out(:,7); % the energy of the secondary star


